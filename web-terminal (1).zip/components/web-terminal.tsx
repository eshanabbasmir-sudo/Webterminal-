"use client"

import { useEffect, useRef, useState } from "react"

type PromptInfo = {
  cwd: string
  user: string
  host: string
  platform: string
}

// Generate a stable-ish session id per mounted terminal.
function makeSessionId() {
  return `sess_${Math.random().toString(36).slice(2)}_${Date.now().toString(36)}`
}

export function WebTerminal() {
  const containerRef = useRef<HTMLDivElement>(null)
  const [ready, setReady] = useState(false)
  const [info, setInfo] = useState<PromptInfo | null>(null)

  useEffect(() => {
    let disposed = false
    const sessionId = makeSessionId()

    // Mutable state closed over by event handlers.
    const state = {
      line: "",
      cursor: 0,
      history: [] as string[],
      historyIndex: -1,
      cwd: "~",
      user: "user",
      host: "vm",
      busy: false,
    }

    let term: import("@xterm/xterm").Terminal | null = null
    let fitAddon: import("@xterm/addon-fit").FitAddon | null = null
    let onResize: (() => void) | null = null

    async function init() {
      const [{ Terminal }, { FitAddon }, { WebLinksAddon }] = await Promise.all([
        import("@xterm/xterm"),
        import("@xterm/addon-fit"),
        import("@xterm/addon-web-links"),
      ])
      // xterm styles
      await import("@xterm/xterm/css/xterm.css")

      if (disposed || !containerRef.current) return

      term = new Terminal({
        cursorBlink: true,
        fontSize: 13,
        fontFamily:
          'ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace',
        theme: {
          background: "#0b0f14",
          foreground: "#d6deeb",
          cursor: "#7ee787",
          cursorAccent: "#0b0f14",
          selectionBackground: "#264f78",
          black: "#0b0f14",
          red: "#ff7b72",
          green: "#7ee787",
          yellow: "#f2cc60",
          blue: "#79c0ff",
          magenta: "#d2a8ff",
          cyan: "#a5d6ff",
          white: "#d6deeb",
          brightBlack: "#6e7681",
          brightRed: "#ffa198",
          brightGreen: "#56d364",
          brightYellow: "#e3b341",
          brightBlue: "#a5d6ff",
          brightMagenta: "#d2a8ff",
          brightCyan: "#b3f0ff",
          brightWhite: "#ffffff",
        },
        allowProposedApi: true,
        convertEol: true,
      })

      fitAddon = new FitAddon()
      term.loadAddon(fitAddon)
      term.loadAddon(new WebLinksAddon())
      term.open(containerRef.current)
      fitAddon.fit()

      onResize = () => fitAddon?.fit()
      window.addEventListener("resize", onResize)

      // Fetch prompt info.
      try {
        const res = await fetch(`/api/terminal?sessionId=${sessionId}`)
        const data: PromptInfo = await res.json()
        state.cwd = data.cwd
        state.user = data.user
        state.host = data.host
        if (!disposed) setInfo(data)
      } catch {
        // ignore
      }

      term.writeln("\x1b[1;32mWeb Terminal\x1b[0m — a real shell running on the server.")
      term.writeln("\x1b[2mType commands and press Enter. Try: ls, pwd, whoami, node -v, echo hello\x1b[0m")
      term.writeln("")
      prompt()
      term.focus()
      setReady(true)

      term.onData(handleData)
    }

    function shortCwd(cwd: string) {
      const parts = cwd.split("/")
      if (parts.length > 4) {
        return ".../" + parts.slice(-2).join("/")
      }
      return cwd
    }

    function promptString() {
      const c = "\x1b[1;32m"
      const p = "\x1b[1;34m"
      const r = "\x1b[0m"
      return `${c}${state.user}@${state.host}${r}:${p}${shortCwd(state.cwd)}${r}$ `
    }

    function prompt() {
      term?.write("\r\n".slice(0, 0)) // no-op keep types happy
      term?.write(promptString())
    }

    function redrawLine() {
      if (!term) return
      // Move to start of input, clear to end, rewrite.
      term.write("\x1b[2K\r")
      term.write(promptString() + state.line)
      // Reposition cursor.
      const back = state.line.length - state.cursor
      if (back > 0) term.write(`\x1b[${back}D`)
    }

    async function runLine(cmd: string) {
      if (!term) return
      state.busy = true
      try {
        const res = await fetch("/api/terminal", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ command: cmd, sessionId }),
        })
        const data: { output: string; cwd: string } = await res.json()
        if (data.output) {
          // Normalize line endings for xterm.
          term.write(data.output.replace(/\r?\n/g, "\r\n"))
          if (!data.output.endsWith("\n")) term.write("\r\n")
        }
        if (data.cwd) state.cwd = data.cwd
      } catch (err) {
        term.write(`\x1b[1;31merror: ${(err as Error).message}\x1b[0m\r\n`)
      } finally {
        state.busy = false
        term.write(promptString())
      }
    }

    function handleData(data: string) {
      if (!term || state.busy) return

      // Handle escape sequences (arrow keys etc.)
      if (data === "\x1b[A") {
        // Up
        if (state.history.length === 0) return
        if (state.historyIndex === -1) state.historyIndex = state.history.length
        state.historyIndex = Math.max(0, state.historyIndex - 1)
        state.line = state.history[state.historyIndex] ?? ""
        state.cursor = state.line.length
        redrawLine()
        return
      }
      if (data === "\x1b[B") {
        // Down
        if (state.history.length === 0) return
        if (state.historyIndex === -1) return
        state.historyIndex += 1
        if (state.historyIndex >= state.history.length) {
          state.historyIndex = -1
          state.line = ""
        } else {
          state.line = state.history[state.historyIndex] ?? ""
        }
        state.cursor = state.line.length
        redrawLine()
        return
      }
      if (data === "\x1b[C") {
        // Right
        if (state.cursor < state.line.length) {
          state.cursor += 1
          term.write("\x1b[C")
        }
        return
      }
      if (data === "\x1b[D") {
        // Left
        if (state.cursor > 0) {
          state.cursor -= 1
          term.write("\x1b[D")
        }
        return
      }
      if (data === "\x1b[H" || data === "\x01") {
        // Home / Ctrl+A
        if (state.cursor > 0) term.write(`\x1b[${state.cursor}D`)
        state.cursor = 0
        return
      }
      if (data === "\x1b[F" || data === "\x05") {
        // End / Ctrl+E
        const fwd = state.line.length - state.cursor
        if (fwd > 0) term.write(`\x1b[${fwd}C`)
        state.cursor = state.line.length
        return
      }

      for (const ch of data) {
        const code = ch.charCodeAt(0)

        if (ch === "\r") {
          // Enter
          term.write("\r\n")
          const cmd = state.line.trim()
          state.line = ""
          state.cursor = 0
          state.historyIndex = -1
          if (cmd) {
            state.history.push(cmd)
            if (cmd === "clear" || cmd === "cls") {
              term.clear()
              term.write(promptString())
            } else {
              void runLine(cmd)
            }
          } else {
            term.write(promptString())
          }
          continue
        }

        if (ch === "\x7f") {
          // Backspace
          if (state.cursor > 0) {
            state.line = state.line.slice(0, state.cursor - 1) + state.line.slice(state.cursor)
            state.cursor -= 1
            redrawLine()
          }
          continue
        }

        if (ch === "\x03") {
          // Ctrl+C
          term.write("^C\r\n")
          state.line = ""
          state.cursor = 0
          state.historyIndex = -1
          term.write(promptString())
          continue
        }

        if (ch === "\x0c") {
          // Ctrl+L clear
          term.clear()
          redrawLine()
          continue
        }

        if (code < 32) {
          // Ignore other control chars.
          continue
        }

        // Printable char: insert at cursor.
        state.line = state.line.slice(0, state.cursor) + ch + state.line.slice(state.cursor)
        state.cursor += 1
        if (state.cursor === state.line.length) {
          term.write(ch)
        } else {
          redrawLine()
        }
      }
    }

    init()

    return () => {
      disposed = true
      if (onResize) window.removeEventListener("resize", onResize)
      term?.dispose()
    }
  }, [])

  return (
    <div className="flex h-full w-full flex-col overflow-hidden rounded-lg border border-[#1c2733] bg-[#0b0f14] shadow-2xl">
      <div className="flex items-center gap-2 border-b border-[#1c2733] bg-[#11161d] px-4 py-2.5">
        <div className="flex gap-2">
          <span className="h-3 w-3 rounded-full bg-[#ff5f57]" />
          <span className="h-3 w-3 rounded-full bg-[#febc2e]" />
          <span className="h-3 w-3 rounded-full bg-[#28c840]" />
        </div>
        <div className="flex-1 text-center font-mono text-xs text-[#7d8695]">
          {info ? `${info.user}@${info.host} — ${info.platform}` : "terminal"}
        </div>
        <div className="w-14" aria-hidden />
      </div>
      <div className="relative flex-1">
        <div ref={containerRef} className="absolute inset-0 p-2" />
        {!ready && (
          <div className="absolute inset-0 flex items-center justify-center font-mono text-sm text-[#7d8695]">
            starting shell…
          </div>
        )}
      </div>
    </div>
  )
}
