import { spawn } from "node:child_process"
import os from "node:os"
import { NextResponse } from "next/server"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

// A marker we use to detect the working directory after each command runs,
// so that `cd` and friends persist across separate requests.
const CWD_MARKER = "__V0_TERM_CWD__"

// Per-session shell state kept in memory on the server. Each browser tab gets
// its own session id, its own working directory, and its own environment.
type Session = {
  cwd: string
  env: NodeJS.ProcessEnv
  lastUsed: number
}

// Persist sessions across hot reloads in dev by stashing them on globalThis.
const globalForSessions = globalThis as unknown as {
  __terminalSessions?: Map<string, Session>
}
const sessions = globalForSessions.__terminalSessions ?? new Map<string, Session>()
globalForSessions.__terminalSessions = sessions

// Clean up sessions that have been idle for more than 30 minutes.
function pruneSessions() {
  const now = Date.now()
  for (const [id, session] of sessions) {
    if (now - session.lastUsed > 30 * 60 * 1000) sessions.delete(id)
  }
}

function getSession(id: string): Session {
  pruneSessions()
  let session = sessions.get(id)
  if (!session) {
    session = {
      cwd: process.cwd(),
      env: { ...process.env },
      lastUsed: Date.now(),
    }
    sessions.set(id, session)
  }
  session.lastUsed = Date.now()
  return session
}

const shell = process.platform === "win32" ? "cmd.exe" : "/bin/bash"

function runCommand(
  command: string,
  session: Session,
  timeoutMs: number,
): Promise<{ output: string; cwd: string }> {
  return new Promise((resolve) => {
    // Run the user's command, then print the resulting cwd so we can persist it.
    const wrapped =
      process.platform === "win32"
        ? `${command} & echo ${CWD_MARKER}%cd%`
        : `${command}\n__v0_status=$?\nprintf '%s%s\\n' '${CWD_MARKER}' "$(pwd)"\nexit $__v0_status`

    const child = spawn(shell, process.platform === "win32" ? ["/c", wrapped] : ["-c", wrapped], {
      cwd: session.cwd,
      env: session.env,
    })

    let stdout = ""
    let stderr = ""
    let killed = false

    const timer = setTimeout(() => {
      killed = true
      child.kill("SIGKILL")
    }, timeoutMs)

    child.stdout.on("data", (d) => {
      stdout += d.toString()
    })
    child.stderr.on("data", (d) => {
      stderr += d.toString()
    })

    child.on("error", (err) => {
      clearTimeout(timer)
      resolve({ output: `${stderr}${err.message}\n`, cwd: session.cwd })
    })

    child.on("close", () => {
      clearTimeout(timer)

      let newCwd = session.cwd
      let cleanStdout = stdout

      // Extract the trailing cwd marker to update session state.
      const idx = stdout.lastIndexOf(CWD_MARKER)
      if (idx !== -1) {
        const after = stdout.slice(idx + CWD_MARKER.length)
        const newline = after.indexOf("\n")
        newCwd = (newline === -1 ? after : after.slice(0, newline)).trim() || session.cwd
        cleanStdout = stdout.slice(0, idx)
      }

      session.cwd = newCwd

      let output = cleanStdout
      if (stderr) output += stderr
      if (killed) output += `\n[command timed out after ${timeoutMs / 1000}s and was terminated]\n`

      resolve({ output, cwd: newCwd })
    })
  })
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const command: string = typeof body.command === "string" ? body.command : ""
    const sessionId: string = typeof body.sessionId === "string" && body.sessionId ? body.sessionId : "default"

    const session = getSession(sessionId)

    if (!command.trim()) {
      return NextResponse.json({ output: "", cwd: session.cwd })
    }

    const { output, cwd } = await runCommand(command, session, 60_000)
    return NextResponse.json({ output, cwd })
  } catch (err) {
    return NextResponse.json(
      { output: `internal error: ${(err as Error).message}\n`, cwd: os.homedir() },
      { status: 500 },
    )
  }
}

// Return the initial working directory / prompt info for a session.
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const sessionId = searchParams.get("sessionId") || "default"
  const session = getSession(sessionId)
  return NextResponse.json({
    cwd: session.cwd,
    user: os.userInfo().username,
    host: os.hostname(),
    platform: process.platform,
  })
}
